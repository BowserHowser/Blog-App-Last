import { Injectable } from '@angular/core';
import { PostModule } from '../Model/post.module';
import * as firebase from 'firebase';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  posts : PostModule[] = [];
  postsSubject = new Subject<PostModule[]>(); 
  constructor() {
    this.getPosts();
   }

   emitPosts(){
    this.postsSubject.next(this.posts);
   } 

   savePosts(){
    firebase.database().ref('/posts').set(this.posts);
   }
   
   getPosts(){
    firebase.database().ref('/posts').on('value',data=>{
      this.posts = data.val() ? data.val() : [];
      this.emitPosts();
    });
   }
  
   createNewPost(newPost : PostModule){
     this.posts.push(newPost);
     this.savePosts();
     this.emitPosts();
   }

   removePost(post : PostModule){
    const postIndexToRemove = this.posts.findIndex(
      (postEl)=>{
          if ( postEl === post ) {
            return true;
          }
      });
      this.posts.splice(postIndexToRemove,1);
      this.savePosts();
      this.emitPosts();
  }
   
  getSinglePost(id : number){
    return new Promise(
      (resolve, reject) => {
        firebase.database().ref('/posts/' + id).once('value').then(
          (data) => {
            resolve(data.val());
          }, (error) => {
            reject(error);
          }
        );
      }
    );
  }
}
