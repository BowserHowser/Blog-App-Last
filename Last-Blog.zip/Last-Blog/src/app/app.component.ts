import { Component } from '@angular/core';
import * as firebase from 'firebase';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Last-Blog';
  constructor(){
    
    // Your web app's Firebase configuration
    var firebaseConfig = {
      apiKey: "****************XGF-OatvQAfMRqo",
      authDomain: "angular************pp.com",
      databaseURL: "https************io.com",
      projectId: "angular-****f",
      storageBucket: "angula*************t.com",
      messagingSenderId: "678822222361",
      appId: "1:67222226361:web:046b28815fc0599a"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    }
  
}
