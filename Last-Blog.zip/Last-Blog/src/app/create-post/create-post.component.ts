import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { PostService } from '../services/post.service';
import { Router } from '@angular/router';
import { PostModule } from '../model/post.module';

@Component({
  selector: 'app-create-post',
  templateUrl: './create-post.component.html',
  styleUrls: ['./create-post.component.scss']
})
export class CreatePostComponent implements OnInit {
  
  postForm : FormGroup;
  constructor(private formBuilder : FormBuilder, private postsServices : PostService, private router : Router) { }

  ngOnInit() {
    this.initForm();
  }

  initForm(){
    this.postForm = this.formBuilder.group({
      titre : ['',Validators.required],
      text : ['',Validators.required],
      likes : ['0',Validators.required]
    });
  }
  onSavePost(){
    const titre = this.postForm.get('titre').value;
    const text = this.postForm.get('text').value;
    const likes = this.postForm.get('likes').value;
    const newPost = new PostModule(titre,text,likes);
    this.postsServices.createNewPost(newPost);
    this.router.navigate(['/posts']);
  }
}
