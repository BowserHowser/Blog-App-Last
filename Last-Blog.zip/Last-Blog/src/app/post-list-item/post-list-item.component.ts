import { Component, OnInit, Input } from '@angular/core';
import { PostModule } from '../Model/post.module';
import { PostService } from '../Services/post.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-list-item',
  templateUrl: './post-list-item.component.html',
  styleUrls: ['./post-list-item.component.scss']
})
export class PostListItemComponent implements OnInit {

  @Input() postTitle : string;
  @Input() postContent : string;
  @Input() postLoveIts : number;
  @Input() index : number;
  

  constructor(private postsServices : PostService , private router : Router) { }

  ngOnInit() {
  }
 
  lastUpdate = new Promise((resolve,reject)=>{
    const date = new Date();
    setTimeout(()=>{resolve(date);},4000);
  });

  onDeletePost(post : PostModule){
    this.postsServices.removePost(post);
  }
  onAime(post){
    let titre = this.postTitle;
    let text = this.postContent;
    this.postLoveIts = +this.postLoveIts+1
    let likes = this.postLoveIts;
    this.onDeletePost(post);
    const newPst = new PostModule(titre,text,likes);
    this.postsServices.createNewPost(newPst);
    this.router.navigate(['/posts']);
  }
  onAimePas(post){
    let titre = this.postTitle;
    let text = this.postContent;
    this.postLoveIts = this.postLoveIts-1
    let likes = this.postLoveIts;
    this.onDeletePost(post);
    const newPst = new PostModule(titre,text,likes);
    this.postsServices.createNewPost(newPst);
    this.router.navigate(['/posts']);
  }
}
