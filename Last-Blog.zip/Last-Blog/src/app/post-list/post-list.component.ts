import { Component, OnInit } from '@angular/core';
import { PostModule } from '../Model/post.module';
import { Subscription } from 'rxjs';
import { PostService } from '../Services/post.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-list',
  templateUrl: './post-list.component.html',
  styleUrls: ['./post-list.component.scss']
})
export class PostListComponent implements OnInit {

  posts : PostModule[];
  postsSubscription : Subscription;
  post : PostModule;

  constructor(private postsServices : PostService , private router : Router) { }

  ngOnInit() {
    this.postsSubscription = this.postsServices.postsSubject.subscribe(
      (posts : PostModule[]) => {
        this.posts = posts;
      }
    );
    this.postsServices.getPosts();
    this.postsServices.emitPosts();
  }

  onDeletePost(post : PostModule){
    this.postsServices.removePost(post);
  }
  
  ngOnDestroy(){
    this.postsSubscription.unsubscribe(); 
  }

}
